package self.frota.guilherme.tools;

/**
 * Created by Frota on 05/08/2017.
 */

public interface ActionQueue {
    boolean action();
}
