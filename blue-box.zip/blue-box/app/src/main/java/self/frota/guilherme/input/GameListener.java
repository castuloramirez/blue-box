package self.frota.guilherme.input;

import android.view.MotionEvent;

/**
 * Created by Frota on 06/08/2017.
 */

public interface GameListener {
    boolean action(MotionEvent e);
}
